"""Framework-agnostic context extraction helpers for observability."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any
from urllib.parse import unquote

from opentelemetry import baggage

_SESSION_BAGGAGE_KEYS = ("eos_session_id", "session_id", "session.id", "eos.session.id")
_USER_BAGGAGE_KEYS = ("user",)


def _extract_baggage_item(baggage_header: str | None, accepted_keys: tuple[str, ...]) -> str | None:
    """Return the first matching baggage value from an incoming baggage header.

    Args:
        baggage_header: Raw value from the HTTP `baggage` header.
        accepted_keys: Allowed key names, expected in lowercase.

    Returns:
        The first decoded non-empty baggage value, or `None` when no match is found.

    Side effects:
        None.
    """
    if not baggage_header:
        return None

    for item in baggage_header.split(","):
        part = item.strip()
        if not part or "=" not in part:
            continue

        key, value = part.split("=", 1)
        if key.strip().lower() in accepted_keys:
            decoded = unquote(value.strip())
            if decoded:
                return decoded

    return None


def _get_session_id_from_baggage() -> str | None:
    """Resolve `session_id` from OpenTelemetry baggage in legacy key order.

    Args:
        None.

    Returns:
        The first non-empty session identifier as string, otherwise `None`.

    Side effects:
        Reads from the OpenTelemetry context for the active request/task.
    """
    for key in _SESSION_BAGGAGE_KEYS:
        value = baggage.get_baggage(key)
        if value:
            return str(value)
    return None


def _get_user_from_baggage() -> str | None:
    """Resolve `user` correlation value from OpenTelemetry baggage.

    Args:
        None.

    Returns:
        The first non-empty user value as string, otherwise `None`.

    Side effects:
        Reads from the OpenTelemetry context for the active request/task.
    """
    for key in _USER_BAGGAGE_KEYS:
        value = baggage.get_baggage(key)
        if value:
            return str(value)
    return None


def _get_header_from_scope(scope: Mapping[str, Any] | dict[str, Any], header_name: str) -> str | None:
    """Fetch a decoded header value from an ASGI scope.

    Args:
        scope: ASGI request scope dictionary with raw `headers`.
        header_name: Header name to lookup (case-insensitive).

    Returns:
        The decoded header value when present, otherwise `None`.

    Side effects:
        None.
    """
    headers = scope.get("headers", []) if isinstance(scope, Mapping) else []
    target = header_name.lower().encode("latin-1")
    for key, value in headers:
        if key.lower() == target:
            return value.decode("latin-1")
    return None
