"""Correlation helpers shared by logging and instrumentation layers."""

from __future__ import annotations

import logging
from typing import Any

import structlog
from opentelemetry import trace

from polly_observability.core.context import _get_session_id_from_baggage, _get_user_from_baggage


def set_correlation_attributes_on_span(span: Any, session_id: str | None, user: str | None) -> None:
    """Attach correlation attributes to the active span.

    Args:
        span: OpenTelemetry span object.
        session_id: Session identifier value if available.
        user: End-user identifier value if available.

    Returns:
        None.

    Side effects:
        Mutates span attributes when values are provided.
    """
    if session_id:
        span.set_attribute("session.id", session_id)
        span.set_attribute("session_id", session_id)
        span.set_attribute("eos_session_id", session_id)
    if user:
        span.set_attribute("user", user)
        span.set_attribute("enduser.id", user)


def add_opentelemetry_spans(logger: Any, log_method: str, event_dict: dict[str, Any]) -> dict[str, Any]:
    """Enrich structlog events with OTel IDs and correlation fields.

    Args:
        logger: Bound logger passed by structlog (unused).
        log_method: Logging method name passed by structlog (unused).
        event_dict: Structured log event dictionary.

    Returns:
        The same event dictionary, enriched in-place.

    Side effects:
        Mutates log payload and may add attributes to the current recording span.
    """
    del logger, log_method

    session_id = (
        event_dict.get("session_id")
        or event_dict.get("eos_session_id")
        or _get_session_id_from_baggage()
    )
    user = event_dict.get("user") or _get_user_from_baggage()

    if session_id:
        session_id = str(session_id)
        event_dict.setdefault("session_id", session_id)
        event_dict.setdefault("eos_session_id", session_id)
    if user:
        user = str(user)
        event_dict.setdefault("user", user)

    span = trace.get_current_span()
    if span.is_recording():
        ctx = span.get_span_context()
        event_dict["trace_id"] = format(ctx.trace_id, "032x")
        event_dict["span_id"] = format(ctx.span_id, "016x")
        set_correlation_attributes_on_span(span, session_id, user)

    return event_dict


class ContextVarsToLogRecordFilter(logging.Filter):
    """Copy structlog contextvars to `LogRecord` attributes for OTLP export.

    Args:
        Inherited from `logging.Filter`.

    Returns:
        Boolean indicating whether record processing should continue.

    Side effects:
        Mutates `logging.LogRecord` by setting `session_id`, `eos_session_id`, and `user`.
    """

    _SESSION_CONTEXT_KEYS = ("session_id", "eos_session_id")
    _USER_CONTEXT_KEYS = ("user",)

    def filter(self, record: logging.LogRecord) -> bool:
        """Apply correlation context onto a log record.

        Args:
            record: Standard-library log record to enrich.

        Returns:
            Always `True` to keep record propagation unchanged.

        Side effects:
            Writes correlation attributes directly on `record`.
        """
        context = structlog.contextvars.get_contextvars()
        session_id = None
        user = None

        for key in self._SESSION_CONTEXT_KEYS:
            value = context.get(key)
            if value:
                session_id = str(value)
                break

        for key in self._USER_CONTEXT_KEYS:
            value = context.get(key)
            if value:
                user = str(value)
                break

        if not session_id:
            session_id = _get_session_id_from_baggage()
        if not user:
            user = _get_user_from_baggage()

        if session_id:
            setattr(record, "session_id", session_id)
            setattr(record, "eos_session_id", session_id)
        if user:
            setattr(record, "user", user)

        return True
