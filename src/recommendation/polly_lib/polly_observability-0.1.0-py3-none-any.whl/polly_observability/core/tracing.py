"""Tracing setup and resource construction utilities."""

from __future__ import annotations

import logging
from typing import Any

from opentelemetry import trace
from opentelemetry.baggage.propagation import W3CBaggagePropagator
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.propagate import set_global_textmap
from opentelemetry.propagators.composite import CompositePropagator
from opentelemetry.propagators.jaeger import JaegerPropagator
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator

LOGGER = logging.getLogger(__name__)


def _build_resource_attributes(settings: Any) -> dict[str, str]:
    """Build OTEL resource attributes from settings.

    Args:
        settings: Settings object exposing `OTEL_SERVICE_NAME` and optional
            `OTEL_RESOURCE_ATTRIBUTES`.

    Returns:
        Mapping of resource attribute keys and values.

    Side effects:
        None.
    """
    attributes = {"service.name": settings.OTEL_SERVICE_NAME}

    if hasattr(settings, "OTEL_RESOURCE_ATTRIBUTES") and settings.OTEL_RESOURCE_ATTRIBUTES:
        for item in settings.OTEL_RESOURCE_ATTRIBUTES.split(","):
            if "=" in item:
                key, value = item.split("=", 1)
                attributes[key.strip()] = value.strip()

    return attributes


def _setup_tracing(settings: Any, resource: Resource) -> TracerProvider | None:
    """Configure OpenTelemetry tracing provider and OTLP span export.

    Args:
        settings: Settings object with tracing-related options.
        resource: OpenTelemetry resource attached to tracer provider.

    Returns:
        Configured tracer provider, or `None` when tracing is disabled/unconfigured.

    Side effects:
        May set global tracer provider, global text-map propagator, and register
        span processors/exporters.
    """
    traces_enabled = getattr(settings, "OTEL_TRACES_ENABLED", True)
    if not traces_enabled:
        return None

    traces_endpoint = getattr(settings, "OTEL_TRACES_EXPORTER_OTLP_ENDPOINT", None) or getattr(
        settings, "OTEL_EXPORTER_OTLP_ENDPOINT", None
    )
    if not traces_endpoint:
        return None

    try:
        current_provider = trace.get_tracer_provider()
        if isinstance(current_provider, TracerProvider):
            tracer_provider = current_provider
        else:
            tracer_provider = TracerProvider(resource=resource)
            trace.set_tracer_provider(tracer_provider)

        # Keep extraction behavior aligned with existing services:
        # W3C trace context + W3C baggage + Jaeger propagation formats.
        set_global_textmap(
            CompositePropagator(
                [
                    TraceContextTextMapPropagator(),
                    W3CBaggagePropagator(),
                    JaegerPropagator(),
                ]
            )
        )

        if not getattr(tracer_provider, "_eos_has_span_exporter", False):
            span_exporter = OTLPSpanExporter(endpoint=traces_endpoint, insecure=True)
            tracer_provider.add_span_processor(BatchSpanProcessor(span_exporter))
            tracer_provider._eos_has_span_exporter = True

        return tracer_provider
    except Exception:
        LOGGER.exception("Failed to setup OTLP tracing")
        return None
