"""Backward-compatible logging entrypoints and exports."""

from __future__ import annotations

from polly_observability.core.context import (
    _SESSION_BAGGAGE_KEYS,
    _USER_BAGGAGE_KEYS,
    _extract_baggage_item,
    _get_header_from_scope,
    _get_session_id_from_baggage,
    _get_user_from_baggage,
)
from polly_observability.core.correlation import (
    ContextVarsToLogRecordFilter,
    add_opentelemetry_spans,
)
from polly_observability.core.tracing import _build_resource_attributes, _setup_tracing
from polly_observability.setup import polly_setup_observability


def polly_setup_logging(settings=None, configure_stdout: bool = True) -> None:
    """Backward-compatible wrapper for the new observability setup API.

    Args:
        settings: Optional settings object; defaults to `OTelSettings()`.
        configure_stdout: Whether to configure stdout console logging.

    Returns:
        None.

    Side effects:
        Configures global tracing/logging providers exactly like
        `eos_setup_observability` for non-framework use.
    """
    polly_setup_observability(
        app=None,
        framework=None,
        settings=settings,
        configure_stdout=configure_stdout,
    )


__all__ = [
    "_SESSION_BAGGAGE_KEYS",
    "_USER_BAGGAGE_KEYS",
    "_extract_baggage_item",
    "_get_header_from_scope",
    "_get_session_id_from_baggage",
    "_get_user_from_baggage",
    "ContextVarsToLogRecordFilter",
    "add_opentelemetry_spans",
    "_build_resource_attributes",
    "_setup_tracing",
    "polly_setup_logging",
]
