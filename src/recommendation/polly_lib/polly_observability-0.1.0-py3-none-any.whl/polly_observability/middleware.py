from __future__ import annotations

from collections.abc import Awaitable, Callable

import structlog
from fastapi import Request
from opentelemetry import baggage, trace
from opentelemetry.context import attach
from starlette.responses import Response

from polly_observability.core.context import (
    _SESSION_BAGGAGE_KEYS,
    _USER_BAGGAGE_KEYS,
    _extract_baggage_item,
)
from polly_observability.core.correlation import set_correlation_attributes_on_span


def _extract_baggage_value(baggage_header: str | None, accepted_keys: tuple[str, ...]) -> str | None:
    """Backward-compatible alias for baggage header extraction.

    Args:
        baggage_header: Raw `baggage` header value.
        accepted_keys: Accepted key names in lookup order.

    Returns:
        The first matching decoded baggage value, or `None`.

    Side effects:
        None.
    """
    return _extract_baggage_item(baggage_header, accepted_keys)


# Middleware remains optional for backwards compatibility.
# Logging now reads eos_session_id directly from OpenTelemetry baggage.
async def context_middleware(
    request: Request,
    call_next: Callable[[Request], Awaitable[Response]],
) -> Response:
    """Bind request correlation data to structlog and current span.

    Args:
        request: Incoming FastAPI request.
        call_next: Next middleware/route callable.

    Returns:
        Response from downstream middleware/handler.

    Side effects:
        Binds and clears structlog contextvars, sets span attributes, and writes
        baggage values into the active OpenTelemetry context.
    """
    # Bind structlog contextvars. This propagates to all logs in this request
    # when applications still choose to use the middleware.
    context_data: dict[str, str] = {}

    # Prefer W3C baggage and keep legacy header fallback for older SDK clients.
    session_id = _extract_baggage_value(request.headers.get("baggage"), _SESSION_BAGGAGE_KEYS)
    user = _extract_baggage_value(request.headers.get("baggage"), _USER_BAGGAGE_KEYS)
    if not session_id:
        session_id = request.headers.get("x-eos-session-id") or request.headers.get(
            "x-session-id"
        )

    # If OTel instrumentation has already extracted baggage, prefer that value.
    session_id = session_id or baggage.get_baggage("eos_session_id") or baggage.get_baggage(
        "session_id"
    )
    user = user or baggage.get_baggage("user")

    if session_id:
        session_id = str(session_id)
        context_data["session_id"] = session_id
        context_data["eos_session_id"] = session_id
    if user:
        context_data["user"] = str(user)

    if context_data:
        structlog.contextvars.bind_contextvars(**context_data)

    # Also tag the active span and ensure baggage propagation for downstream services.
    if session_id or user:
        span = trace.get_current_span()
        if span.is_recording():
            user_value = str(user) if user else None
            set_correlation_attributes_on_span(span, session_id, user_value)

        # Add baggage keys for compatibility with mixed-service ecosystems.
        if session_id:
            attach(baggage.set_baggage("eos_session_id", session_id))
            attach(baggage.set_baggage("session_id", session_id))
        if user:
            attach(baggage.set_baggage("user", str(user)))

    try:
        response = await call_next(request)
        return response
    finally:
        # Clear context after request to avoid leaking to other requests
        structlog.contextvars.clear_contextvars()
