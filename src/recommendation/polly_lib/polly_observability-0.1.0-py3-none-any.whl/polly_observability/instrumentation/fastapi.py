"""FastAPI instrumentation adapter."""

from __future__ import annotations

import logging
from collections.abc import Mapping
from typing import Any

from opentelemetry.sdk.trace import TracerProvider

from polly_observability.core.context import (
    _SESSION_BAGGAGE_KEYS,
    _USER_BAGGAGE_KEYS,
    _extract_baggage_item,
    _get_header_from_scope,
    _get_session_id_from_baggage,
    _get_user_from_baggage,
)
from polly_observability.core.correlation import set_correlation_attributes_on_span
from polly_observability.instrumentation.base import Instrumentor

LOGGER = logging.getLogger(__name__)


def _parse_excluded_fastapi_spans(settings: Any) -> list[str] | None:
    """Parse valid FastAPI internal span exclusions from settings.

    Args:
        settings: Settings object carrying `OTEL_FASTAPI_EXCLUDE_SPANS`.

    Returns:
        List of valid span names (`receive`, `send`) or `None`.

    Side effects:
        None.
    """
    raw = getattr(settings, "OTEL_FASTAPI_EXCLUDE_SPANS", "")
    if not raw:
        return None
    allowed = {"receive", "send"}
    spans = [item.strip().lower() for item in raw.split(",") if item.strip()]
    spans = [span for span in spans if span in allowed]
    return spans or None


def _server_request_hook(span: Any, scope: Mapping[str, Any] | dict[str, Any]) -> None:
    """Attach correlation attributes on incoming FastAPI requests.

    Args:
        span: Server span created by OpenTelemetry FastAPI instrumentation.
        scope: ASGI request scope.

    Returns:
        None.

    Side effects:
        Mutates span attributes with `session_id` and `user` correlation values.
    """
    if not span or not span.is_recording():
        return

    baggage_header = _get_header_from_scope(scope, "baggage")
    session_id = _extract_baggage_item(baggage_header, _SESSION_BAGGAGE_KEYS)
    user = _extract_baggage_item(baggage_header, _USER_BAGGAGE_KEYS)

    if not session_id:
        session_id = _get_header_from_scope(scope, "x-eos-session-id") or _get_header_from_scope(
            scope, "x-session-id"
        )

    if not session_id:
        session_id = _get_session_id_from_baggage()
    if not user:
        user = _get_user_from_baggage()

    set_correlation_attributes_on_span(span, session_id, user)


class FastAPIObservabilityInstrumentor(Instrumentor):
    """Install FastAPI tracing instrumentation using OpenTelemetry APIs."""

    def instrument(self, app: Any, tracer_provider: TracerProvider | None, settings: Any) -> None:
        """Instrument a FastAPI app instance.

        Args:
            app: FastAPI application object.
            tracer_provider: Configured EOS tracer provider.
            settings: EOS settings used to parse excluded spans.

        Returns:
            None.

        Side effects:
            Installs OpenTelemetry hooks into the FastAPI app.
        """
        if app is None:
            LOGGER.warning("FastAPI instrumentation skipped: app is None")
            return

        if getattr(app, "_eos_otel_instrumented", False):
            return

        try:
            from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
        except ImportError:
            LOGGER.warning(
                "FastAPI instrumentation package is unavailable. "
                "Install opentelemetry-instrumentation-fastapi to enable tracing."
            )
            return

        excluded_spans = _parse_excluded_fastapi_spans(settings)

        try:
            FastAPIInstrumentor.instrument_app(
                app,
                tracer_provider=tracer_provider,
                exclude_spans=excluded_spans,
                server_request_hook=_server_request_hook,
            )
            app._eos_otel_instrumented = True
        except Exception:
            LOGGER.exception("Failed to instrument FastAPI app")
