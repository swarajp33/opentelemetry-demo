"""Django instrumentation adapter."""

from __future__ import annotations

import logging
from typing import Any

from opentelemetry.sdk.trace import TracerProvider

from polly_observability.instrumentation.base import Instrumentor

LOGGER = logging.getLogger(__name__)


class DjangoObservabilityInstrumentor(Instrumentor):
    """Install Django tracing instrumentation using OpenTelemetry APIs."""

    def instrument(self, app: Any, tracer_provider: TracerProvider | None, settings: Any) -> None:
        """Instrument Django process-level request handling.

        Args:
            app: Django app object (unused; kept for interface consistency).
            tracer_provider: Configured EOS tracer provider.
            settings: EOS settings object (unused for Django at the moment).

        Returns:
            None.

        Side effects:
            Calls `DjangoInstrumentor().instrument()` which patches Django internals.
        """
        del app, settings

        try:
            from opentelemetry.instrumentation.django import DjangoInstrumentor
        except ImportError:
            LOGGER.warning(
                "Django instrumentation package is unavailable. "
                "Install opentelemetry-instrumentation-django to enable tracing."
            )
            return

        kwargs: dict[str, Any] = {}
        if tracer_provider is not None:
            kwargs["tracer_provider"] = tracer_provider

        try:
            DjangoInstrumentor().instrument(**kwargs)
        except Exception:
            LOGGER.exception("Failed to instrument Django application")
