"""gRPC instrumentation adapter."""

from __future__ import annotations

import logging
from typing import Any

from opentelemetry.sdk.trace import TracerProvider

from polly_observability.instrumentation.base import Instrumentor

LOGGER = logging.getLogger(__name__)


class GrpcObservabilityInstrumentor(Instrumentor):
    """Install gRPC server tracing instrumentation using OpenTelemetry APIs."""

    def instrument(self, app: Any, tracer_provider: TracerProvider | None, settings: Any) -> None:
        """Instrument gRPC server creation and handling.

        Args:
            app: gRPC server object (unused for global instrumentor mode).
            tracer_provider: Configured EOS tracer provider.
            settings: EOS settings object (unused for gRPC at the moment).

        Returns:
            None.

        Side effects:
            Patches both `grpc.server()` and `grpc.aio.server()` globally when
            the corresponding OpenTelemetry instrumentors are installed.
        """
        del settings

        grpc_server_methods = ("add_insecure_port", "add_secure_port", "start", "wait_for_termination")
        if app is not None and all(hasattr(app, method) for method in grpc_server_methods):
            LOGGER.warning(
                "gRPC observability patches server creation globally. "
                "Call polly_setup_observability(..., framework='grpc') before "
                "creating the gRPC server instance."
            )

        try:
            import opentelemetry.instrumentation.grpc as grpc_instrumentation
        except ImportError:
            LOGGER.warning(
                "gRPC instrumentation package is unavailable. "
                "Install opentelemetry-instrumentation-grpc to enable tracing."
            )
            return

        kwargs: dict[str, Any] = {}
        if tracer_provider is not None:
            kwargs["tracer_provider"] = tracer_provider

        instrumented_any = False
        instrumentors = (
            ("grpc.server", getattr(grpc_instrumentation, "GrpcInstrumentorServer", None)),
            ("grpc.aio.server", getattr(grpc_instrumentation, "GrpcAioInstrumentorServer", None)),
        )

        for target, instrumentor_cls in instrumentors:
            if instrumentor_cls is None:
                continue

            try:
                instrumentor_cls().instrument(**kwargs)
                instrumented_any = True
            except Exception:
                LOGGER.exception("Failed to instrument %s", target)

        if not instrumented_any:
            LOGGER.warning(
                "No compatible gRPC server instrumentor was found. "
                "Update opentelemetry-instrumentation-grpc to enable tracing."
            )
