"""Framework-specific OpenTelemetry instrumentation adapters."""

from .base import Instrumentor
from .django import DjangoObservabilityInstrumentor
from .fastapi import FastAPIObservabilityInstrumentor
from .grpc import GrpcObservabilityInstrumentor

__all__ = [
    "Instrumentor",
    "FastAPIObservabilityInstrumentor",
    "DjangoObservabilityInstrumentor",
    "GrpcObservabilityInstrumentor",
]
