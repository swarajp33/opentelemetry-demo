from pydantic_settings import BaseSettings


class OTelSettings(BaseSettings):
    """
    Common settings for OpenTelemetry and Logging.
    Inherit from this class in your application's Settings.
    """

    # Logging
    LOG_LEVEL: str = "INFO"
    JSON_LOGS: bool = True
    LOG_FILE: str | None = None

    # OpenTelemetry
    OTEL_EXPORTER_OTLP_ENDPOINT: str = "http://eos-storage:4317"
    OTEL_SERVICE_NAME: str = "unknown-service"
    OTEL_RESOURCE_ATTRIBUTES: str = ""
    OTEL_TRACES_ENABLED: bool = True
    OTEL_TRACES_EXPORTER_OTLP_ENDPOINT: str | None = None
    OTEL_FASTAPI_EXCLUDE_SPANS: str = "receive,send"
