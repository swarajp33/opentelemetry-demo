"""Base interface for framework instrumentation wrappers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from opentelemetry.sdk.trace import TracerProvider


class Instrumentor(ABC):
    """Common interface implemented by framework-specific instrumentors."""

    @abstractmethod
    def instrument(self, app: Any, tracer_provider: TracerProvider | None, settings: Any) -> None:
        """Instrument an application/framework with OpenTelemetry hooks.

        Args:
            app: Application or framework object to instrument.
            tracer_provider: Active tracer provider configured for EOS.
            settings: EOS settings object with framework-specific options.

        Returns:
            None.

        Side effects:
            Installs instrumentation hooks and/or monkey patches in the target
            OpenTelemetry instrumentor implementation.
        """
        raise NotImplementedError
