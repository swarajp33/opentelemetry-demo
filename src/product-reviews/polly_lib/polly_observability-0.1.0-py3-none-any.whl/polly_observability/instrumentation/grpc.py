"""gRPC instrumentation adapter."""

from __future__ import annotations

import logging
from typing import Any

from opentelemetry.sdk.trace import TracerProvider

from polly_observability.instrumentation.base import Instrumentor

LOGGER = logging.getLogger(__name__)


class GrpcObservabilityInstrumentor(Instrumentor):
    """Install gRPC server tracing instrumentation using OpenTelemetry APIs."""

    def instrument(self, app: Any, tracer_provider: TracerProvider | None, settings: Any) -> None:
        """Instrument gRPC server creation and handling.

        Args:
            app: gRPC server object (unused for global instrumentor mode).
            tracer_provider: Configured EOS tracer provider.
            settings: EOS settings object (unused for gRPC at the moment).

        Returns:
            None.

        Side effects:
            Calls `GrpcInstrumentorServer().instrument()` which patches gRPC
            server instrumentation globally.
        """
        del app, settings

        try:
            from opentelemetry.instrumentation.grpc import GrpcInstrumentorServer
        except ImportError:
            LOGGER.warning(
                "gRPC instrumentation package is unavailable. "
                "Install opentelemetry-instrumentation-grpc to enable tracing."
            )
            return

        kwargs: dict[str, Any] = {}
        if tracer_provider is not None:
            kwargs["tracer_provider"] = tracer_provider

        try:
            GrpcInstrumentorServer().instrument(**kwargs)
        except Exception:
            LOGGER.exception("Failed to instrument gRPC server")
