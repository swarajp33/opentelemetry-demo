"""Structlog and OpenTelemetry logging setup utilities."""

from __future__ import annotations

import logging
import sys
from typing import Any

import structlog
from opentelemetry._logs import get_logger_provider, set_logger_provider
from opentelemetry.exporter.otlp.proto.grpc._log_exporter import OTLPLogExporter
from opentelemetry.sdk._logs import LoggerProvider, LoggingHandler
from opentelemetry.sdk._logs.export import BatchLogRecordProcessor
from opentelemetry.sdk.resources import Resource

from polly_observability.core.correlation import ContextVarsToLogRecordFilter, add_opentelemetry_spans

LOGGER = logging.getLogger(__name__)


def _build_shared_processors() -> list[Any]:
    """Create the shared processor pipeline used by structlog formatters.

    Args:
        None.

    Returns:
        Ordered processor list reused for structlog and stdlib handlers.

    Side effects:
        None.
    """
    return [
        structlog.contextvars.merge_contextvars,
        add_opentelemetry_spans,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
    ]


def _configure_structlog(shared_processors: list[Any]) -> None:
    """Initialize structlog with a stdlib-compatible processor chain.

    Args:
        shared_processors: Processor list that enriches every log event.

    Returns:
        None.

    Side effects:
        Configures global structlog behavior for the process.
    """
    structlog.configure(
        processors=shared_processors + [structlog.stdlib.ProcessorFormatter.wrap_for_formatter],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )


def setup_logging(settings: Any, resource: Resource, configure_stdout: bool = True) -> None:
    """Configure stdlib logging, structlog, and OTLP log exporting.

    Args:
        settings: Settings object containing logging and OTLP options.
        resource: OpenTelemetry resource attached to OTLP logger provider.
        configure_stdout: If `True`, attaches a stdout handler with structlog rendering.

    Returns:
        None.

    Side effects:
        Mutates root logger handlers/level, configures structlog globally, and may
        set global OpenTelemetry logger provider.
    """
    shared_processors = _build_shared_processors()
    _configure_structlog(shared_processors)

    root_logger = logging.getLogger()
    root_logger.setLevel(settings.LOG_LEVEL.upper())

    if configure_stdout:
        console_formatter = structlog.stdlib.ProcessorFormatter(
            foreign_pre_chain=shared_processors,
            processors=[
                structlog.stdlib.ProcessorFormatter.remove_processors_meta,
                structlog.processors.JSONRenderer()
                if settings.JSON_LOGS
                else structlog.dev.ConsoleRenderer(),
            ],
        )
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(console_formatter)
        root_logger.addHandler(console_handler)

    if hasattr(settings, "OTEL_EXPORTER_OTLP_ENDPOINT") and settings.OTEL_EXPORTER_OTLP_ENDPOINT:
        try:
            logger_provider = LoggerProvider(resource=resource)
            try:
                set_logger_provider(logger_provider)
            except Exception:
                # Another component (for example auto-instrumentation) might already
                # have set the global provider.
                logger_provider = get_logger_provider()

            otlp_exporter = OTLPLogExporter(
                endpoint=settings.OTEL_EXPORTER_OTLP_ENDPOINT,
                insecure=True,
            )
            logger_provider.add_log_record_processor(BatchLogRecordProcessor(otlp_exporter))

            otlp_handler = LoggingHandler(level=logging.NOTSET, logger_provider=logger_provider)
            otlp_handler.addFilter(ContextVarsToLogRecordFilter())
            root_logger.addHandler(otlp_handler)
        except Exception:
            LOGGER.exception("Failed to setup OTLP logging")

    # Keep noisy uvicorn channels disabled as in previous implementation.
    logging.getLogger("uvicorn.access").handlers = []
    logging.getLogger("uvicorn.access").propagate = False
    logging.getLogger("uvicorn.error").handlers = []
    logging.getLogger("uvicorn.error").propagate = False
