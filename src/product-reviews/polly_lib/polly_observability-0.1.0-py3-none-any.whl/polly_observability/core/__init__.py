"""Core, framework-agnostic observability building blocks."""

from .context import (
    _SESSION_BAGGAGE_KEYS,
    _USER_BAGGAGE_KEYS,
    _extract_baggage_item,
    _get_header_from_scope,
    _get_session_id_from_baggage,
    _get_user_from_baggage,
)
from .correlation import (
    ContextVarsToLogRecordFilter,
    add_opentelemetry_spans,
    set_correlation_attributes_on_span,
)
from .logging import setup_logging
from .tracing import _build_resource_attributes, _setup_tracing

__all__ = [
    "_SESSION_BAGGAGE_KEYS",
    "_USER_BAGGAGE_KEYS",
    "_extract_baggage_item",
    "_get_header_from_scope",
    "_get_session_id_from_baggage",
    "_get_user_from_baggage",
    "ContextVarsToLogRecordFilter",
    "add_opentelemetry_spans",
    "set_correlation_attributes_on_span",
    "setup_logging",
    "_build_resource_attributes",
    "_setup_tracing",
]
