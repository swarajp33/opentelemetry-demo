"""Main setup entrypoint for EOS observability."""

from __future__ import annotations

import logging
from typing import Any

from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider

from polly_observability.core.logging import setup_logging
from polly_observability.core.tracing import _build_resource_attributes, _setup_tracing
from polly_observability.instrumentation.base import Instrumentor
from polly_observability.instrumentation.django import DjangoObservabilityInstrumentor
from polly_observability.instrumentation.fastapi import FastAPIObservabilityInstrumentor
from polly_observability.instrumentation.grpc import GrpcObservabilityInstrumentor
from polly_observability.settings import OTelSettings

LOGGER = logging.getLogger(__name__)


def _is_grpc_server_object(app: Any) -> bool:
    """Heuristically determine whether an object is a gRPC server.

    Args:
        app: Runtime application object passed by caller.

    Returns:
        `True` when the object shape and type strongly resemble a gRPC server.

    Side effects:
        None.
    """
    app_type = type(app)
    module_name = getattr(app_type, "__module__", "").lower()
    type_name = getattr(app_type, "__name__", "").lower()
    if "grpc" in module_name and "server" in type_name:
        return True

    grpc_server_methods = ("add_insecure_port", "add_secure_port", "start", "wait_for_termination")
    return all(hasattr(app, method) for method in grpc_server_methods)


def detect_framework(app: Any) -> str | None:
    """Auto-detect framework identifier for instrumentation.

    Args:
        app: Runtime application object to inspect.

    Returns:
        One of `fastapi`, `django`, `grpc`, or `None` if unknown.

    Side effects:
        None.
    """
    if app is None:
        return None

    app_type = type(app)
    module_name = getattr(app_type, "__module__", "").lower()

    if "fastapi" in module_name:
        return "fastapi"
    if "django" in module_name:
        return "django"
    if _is_grpc_server_object(app):
        return "grpc"

    return None


def get_instrumentor(framework: str) -> Instrumentor | None:
    """Resolve framework name to an instrumentor implementation.

    Args:
        framework: Framework identifier (`fastapi`, `django`, or `grpc`).

    Returns:
        Matching instrumentor instance, or `None` for unsupported names.

    Side effects:
        None.
    """
    normalized = framework.strip().lower()
    if normalized == "fastapi":
        return FastAPIObservabilityInstrumentor()
    if normalized == "django":
        return DjangoObservabilityInstrumentor()
    if normalized == "grpc":
        return GrpcObservabilityInstrumentor()
    return None


def polly_setup_observability(
    app: Any = None,
    framework: str | None = None,
    settings: Any = None,
    configure_stdout: bool = True,
) -> None:
    """Configure EOS observability and optionally instrument an app.

    Args:
        app: Application/server object. Instrumentation is skipped when `None`.
        framework: Optional framework override (`fastapi`, `django`, `grpc`).
        settings: Settings object; defaults to `OTelSettings()` when omitted.
        configure_stdout: Whether to add the default stdout handler.

    Returns:
        None.

    Side effects:
        Configures global tracing/logging providers and may instrument framework
        internals depending on the detected or explicitly provided framework.
    """
    if settings is None:
        settings = OTelSettings()

    resource = Resource.create(_build_resource_attributes(settings))
    tracer_provider: TracerProvider | None = _setup_tracing(settings, resource)
    setup_logging(settings=settings, resource=resource, configure_stdout=configure_stdout)

    if app is None:
        return

    selected_framework = framework.lower().strip() if framework else detect_framework(app)
    if not selected_framework:
        LOGGER.warning(
            "Could not detect framework for app type '%s'; skipping instrumentation.",
            type(app).__name__,
        )
        return

    instrumentor = get_instrumentor(selected_framework)
    if instrumentor is None:
        LOGGER.warning("Unsupported framework '%s'; skipping instrumentation.", selected_framework)
        return

    instrumentor.instrument(app=app, tracer_provider=tracer_provider, settings=settings)
