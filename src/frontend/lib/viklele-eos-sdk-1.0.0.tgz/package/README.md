# 🎯 EOS Browser SDK

> **Enterprise Observability System** - Session Replay & Frontend Observability for Modern Web Applications

The **EOS Browser SDK** enables comprehensive session recording, console log capture, and network activity tracking for your web applications. It integrates seamlessly with the **EOS (Enterprise Observability System)** to provide pixel-perfect session replay and end-to-end observability.

---

## ✨ Features

- 🎬 **Session Recording**: Records DOM mutations using `rrweb` to replay user sessions pixel-perfectly
- 👁️ **Frontend Observability**: Automatically captures console logs, errors, and unhandled promise rejections
- 🌐 **Network Tracing**: Intercepts `fetch` and `XHR` requests to inject `traceparent` and W3C `baggage` headers for distributed tracing
- 🔒 **Privacy First**: Built-in PII masking for text, inputs, and specific DOM elements
- ⏱️ **Idle Detection**: Automatically signals end-of-session when the user is inactive
- 📊 **OpenTelemetry Ready**: Designed to work alongside OpenTelemetry for trace correlation

---

## 🚀 Framework Compatibility

The EOS SDK is built as a **framework-agnostic** standard JavaScript library. It works seamlessly with all modern frameworks and libraries:

| Framework | Supported |
|-----------|-----------|
| ⚛️ **React** / **Next.js** | ✅ |
| 🅰️ **Angular** | ✅ |
| 💚 **Vue.js** / **Nuxt** | ✅ |
| 🔥 **Svelte** | ✅ |
| 📜 **Vanilla JavaScript** / **jQuery** | ✅ |

---

# 🔧 Internal: Build & Development

This section is for developers working on the EOS SDK itself.

## 🏗️ Building the SDK

```bash
# Install dependencies
npm install
# or
pnpm install

# Build TypeScript modules
npm run build
# or
pnpm run build

# Create distributable package
npm pack
# or
pnpm pack
```

This will generate:
- **TypeScript modules** in `dist/` for npm installation
- **Package archive** (e.g., `viklele-eos-sdk-1.0.0.tgz`) for distribution

---

# � Customer Integration Guide

This section is for customers integrating the EOS SDK into their applications.

## �📦 Installation

The SDK is delivered as a bundled NPM package (`.tgz` file) or can be installed from a registry if published.

### Step 1: Copy the Artifact
Place the `.tgz` file in your project's `lib/` folder:
```
your-project/
├── lib/
│   └── viklele-eos-sdk-1.0.0.tgz
├── package.json
└── ...
```

### Step 2: Update package.json
Add the SDK as a local file dependency:

```json
{
  "dependencies": {
    "@viklele/eos-sdk": "file:./lib/viklele-eos-sdk-1.0.0.tgz"
  }
}
```

### Step 3: Install
```bash
npm install
# or
pnpm install
```

### Registry Installation (Alternative)
If published to a private registry:
```bash
npm install @viklele/eos-sdk
# or
pnpm add @viklele/eos-sdk
```

---

## 🎯 Quick Start

Initialize the SDK at the entry point of your application (e.g., `index.js`, `main.ts`, `App.tsx`).

```typescript
import EOS from '@viklele/eos-sdk';

const eos = new EOS({
  // 1. Connection
  apiUrl: 'https://api.your-eos-instance.com', // Your EOS Ingestion Endpoint
  otelEndpoint: 'http://localhost:4318',       // Optional: For OTel trace exports

  // 2. Identity (Context)
  orgName: 'acme-corp',
  appName: 'retail-pos-app',
  appVersion: '1.2.0',
  
  // 3. User Identity (Optional but recommended)
  userName: 'john.doe@example.com',      // Platform User
  clientUserName: 'customer-12345',      // End Customer (if applicable)
  
  // 4. Location/Hierarchy (Optional)
  facilityName: 'store-101',
  terminalName: 'pos-3',
  region: 'us-east-1',
});

// Start Recording
eos.start().then(() => {
  console.log('✅ EOS Recording started');
});
```

---

## ⚙️ Configuration Options

| Option | Type | Required | Description |
|--------|------|----------|-------------|
| `apiUrl` | `string` | **Yes** ✅ | The base URL of the EOS Ingestion API. |
| `orgName` | `string` | **Yes** ✅ | The name of your organization. Used for data segmentation. |
| `appName` | `string` | **Yes** ✅ | The name of the application being recorded. |
| `appVersion` | `string` | No | Version of the application (e.g., commit hash or semver). |
| `userName` | `string` | No | Identifier for the internal user (e.g., employee). |
| `clientUserName` | `string` | No | Identifier for the external user (e.g., customer). |
| `user` | `string` | No | Explicit baggage `user` value for trace list display (falls back to `clientUserName`, then `userName`). |
| `facilityName` | `string` | No | Physical location name (e.g., Store ID). |
| `terminalName` | `string` | No | Device identifier (e.g., POS ID). |
| `maskingEnabled` | `boolean` | No | Whether to mask inputs and text (Default: `true`). |
| `maskingRules` | `string[]` | No | List of CSS selectors to mask specifically. |
| `enableOpenTelemetry` | `boolean` | No | Enable OTel tracer integration (Default: `false`). |
| `batchSize` | `number` | No | Number of events to buffer before sending (Default: `100`). |

---

## 🔒 Privacy & Masking

EOS is designed with **privacy in mind**. By default, all input fields are masked. You can customize masking using CSS classes:

- Add class `eos-mask` to any element to mask it and its children
- Add class `eos-ignore` to prevent recording of an element entirely

```html
<!-- This input's value will be hidden in replay -->
<input type="text" class="eos-mask" />

<!-- This entire div will be greyed out -->
<div class="eos-mask">
  <p>Sensitive Info</p>
</div>
```

---

## 🛠️ API Methods

### `start()`
Initializes the session, connects to the backend, and starts recording.
```typescript
await eos.start();
```

### `stop()`
Stops recording and completes the session. Use this when the user logs out.
```typescript
await eos.stop();
```

### `getSessionId()`
Returns the current active Session ID (UUID). Useful for correlating with other tools.
```typescript
const sessionId = eos.getSessionId();
console.log('Session ID:', sessionId);
```

---

## 🔗 Backend Correlation

The SDK automatically injects W3C `baggage` with:
- `eos_session_id=<session-id>`
- `user=<user-value>`

into all `fetch` and `XHR` requests made by your application. This allows backend services to read both session and user context from OpenTelemetry baggage and correlate logs/traces with the frontend session.

**Important**: Ensure your allowed CORS headers on the backend include `baggage`.

---

## 🐳 Docker Integration

If you are containerizing your application (e.g., for deployment), ensure the SDK bundle is copied into the image context before installing dependencies.

**Example Dockerfile:**

```dockerfile
FROM node:18-alpine

WORKDIR /app

# 1. Copy package.json and lock files
COPY package.json package-lock.json ./

# 2. Copy the SDK library (ensure the path matches your package.json)
RUN mkdir -p lib
COPY lib/viklele-eos-sdk-1.0.0.tgz ./lib/

# 3. Install dependencies
# This will pick up the local file dependency defined in package.json
RUN npm install

# 4. Copy the rest of your application code
COPY . .

# 5. Build & Start
RUN npm run build
CMD ["npm", "start"]
```

---

## 🔧 Troubleshooting

| Issue | Solution |
|-------|----------|
| **CORS Errors** | Ensure `apiUrl` accepts requests from your domain and allows headers: `Content-Type`, `baggage` |
| **No Data Appearing** | Check the browser console. EOS logs all major activities with prefix `[EOS]` |
| **Session Not Starting** | Verify `apiUrl`, `orgName`, and `appName` are correctly configured |
| **Network Requests Not Traced** | Ensure `enableOpenTelemetry` is set to `true` if you want OTel integration |

---

## 🤝 Support

For issues, questions, or feature requests, please contact your EOS administrator or visit the EOS documentation portal.
